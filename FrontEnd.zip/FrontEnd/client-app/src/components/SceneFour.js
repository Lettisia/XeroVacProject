import React, { Component } from "react";

class SceneFour extends React.Component {
    render() {
        return(
        <div>
            <h1>Scene Four</h1>
            <p>You visit the Saloon, as you know Johnny is a frequent visitor. You now suspect that Johnny has something to do with the murder because his coin was found on Clayton’s person.</p> 
            <p>You ask Johnny about his whereabouts and he says he returned to the Saloon after coming to the station. He says to ask the barkeep if you don’t believe him.</p> 
            <p>You approach the barkeep and he confirms Johnny’s whereabouts, as you’re talking the room darkens and there is an unnatural chill.....</p>
                <p> Suddenly there is a loud boom and the Cowboy Killer appears, screaming a haunting scream!!.</p>
            <p>She then says, “I will slay you all and drag you to depths...OF HELL!”.</p>

            <p>(in the background, Can-Can Girl: <b>“YAS QUEEN SLAY!”</b>)</p>

        </div>
        )
    
    }

}
export default SceneFour;