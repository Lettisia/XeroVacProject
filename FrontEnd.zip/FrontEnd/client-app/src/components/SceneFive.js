import React, { Component } from "react";


class SceneFive extends React.Component {
    render() {
        return(
        <div>
            <h1>Scene Five</h1>
            <p>You go to cemetery to confront Clementine the Cowboy Killer...</p> 
            <p>You draw your gun to finally kill her and avenge your beloved father, Theodore!</p>
            <p> You try to fire, but before you do, you feel burning pain in your chest. You look and see blood gushing out...</p>
            <p> She was too fast! You fall over, clutching your chest on the cold stone ground.</p>
        </div>
        )
    }

}
export default SceneFive;