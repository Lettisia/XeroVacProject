import React, { Component } from "react";


class SceneTwo extends React.Component {
    render() {
        return(
        <div>
            <h1>Scene Two</h1>
            <p>
                 Johnny the Cowboy bursts into the room and tells you that he’s heard screaming from the old cemetery and that some graves have been disrupted...
                 You have been interrupted, you were about to let the town drunk go free and you are still holding the key...</p>
            <p> Sheriff goes out of the office, down main street to the old lady Dolores’ house...</p>
        </div>
        )
    
    }

}
export default SceneTwo;